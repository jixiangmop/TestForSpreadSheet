﻿function fresh()
{
    
    window.location.reload();

}